import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-PagNotFound',
  templateUrl: './PagNotFound.component.html',
  styleUrls: ['./PagNotFound.component.css']
})
export class PagNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
