/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AEspacioPipe } from './AEspacio.pipe';

describe('Pipe: AEspacioe', () => {
  it('create an instance', () => {
    let pipe = new AEspacioPipe();
    expect(pipe).toBeTruthy();
  });
});
